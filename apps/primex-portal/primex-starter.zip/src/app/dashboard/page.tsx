import { Title } from "rizzui";

export default function Home() {
  return (
    <>
      <Title>Isomorphic Stater Template</Title>
    </>
  );
}
